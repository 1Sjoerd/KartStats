﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalCRUD
{
    public class DbHelper
    {
        private MySqlConnection connection;

        public DbHelper()
        {
            string server = "localhost";
            string database = "dieren";
            string uid = "root";
            string password = "";
            string connectionString = $"SERVER={server};DATABASE={database};UID={uid};PASSWORD={password};";

            connection = new MySqlConnection(connectionString);
        }

        public bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                return false;
            }
        }

        public bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                return false;
            }
        }

        public void Insert(string name, int age, string species)
        {
            string query = $"INSERT INTO Dieren (Name, Age, Species) VALUES('{name}', {age}, '{species}')";

            if (OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                CloseConnection();
            }
        }

        public void Update(int id, string name, int age, string species)
        {
            string query = $"UPDATE Dieren SET Name = '{name}', Age = {age}, Species = '{species}' WHERE Id = {id}";

            if (OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                CloseConnection();
            }
        }

        public void Delete(int id)
        {
            string query = $"DELETE FROM Dieren WHERE Id = {id}";

            if (OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                CloseConnection();
            }
        }

        public List<Dier> SelectAll()
        {
            string query = "SELECT * FROM Dieren";
            List<Dier> dieren = new List<Dier>();

            if (OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    Dier dier = new Dier
                    {
                        Id = int.Parse(dataReader["Id"].ToString()),
                        Name = dataReader["Name"].ToString(),
                        Age = int.Parse(dataReader["Age"].ToString()),
                        Species = dataReader["Species"].ToString()
                    };

                    dieren.Add(dier);
                }

                dataReader.Close();
                CloseConnection();
            }

            return dieren;
        }
    }
}
