﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AnimalCRUD
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DbHelper dbHelper = new DbHelper();
        private List<Dier> dieren = new List<Dier>();

        public MainWindow()
        {
            InitializeComponent();
            LoadDieren();
        }

        private void LoadDieren()
        {
            dieren = dbHelper.SelectAll();
            listBoxDieren.ItemsSource = dieren;
        }

        private void ButtonToevoegen_Click(object sender, RoutedEventArgs e)
        {
            string name = textBoxName.Text;
            int age = int.Parse(textBoxAge.Text);
            string species = textBoxSpecies.Text;

            dbHelper.Insert(name, age, species);

            LoadDieren();
        }

        private void ButtonBijwerken_Click(object sender, RoutedEventArgs e)
        {
            Dier selectedDier = listBoxDieren.SelectedItem as Dier;

            if (selectedDier != null)
            {
                int id = selectedDier.Id;
                string name = textBoxName.Text;
                int age = int.Parse(textBoxAge.Text);
                string species = textBoxSpecies.Text;

                dbHelper.Update(id, name, age, species);

                LoadDieren();
            }
        }

        private void ButtonVerwijderen_Click(object sender, RoutedEventArgs e)
        {
            Dier selectedDier = listBoxDieren.SelectedItem as Dier;

            if (selectedDier != null)
            {
                int id = selectedDier.Id;

                dbHelper.Delete(id);

                LoadDieren();
            }
        }

        private void ListBoxDieren_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Dier selectedDier = listBoxDieren.SelectedItem as Dier;

            if (selectedDier != null)
            {
                textBoxName.Text = selectedDier.Name;
                textBoxAge.Text = selectedDier.Age.ToString();
                textBoxSpecies.Text = selectedDier.Species;
            }
        }
    }
}
