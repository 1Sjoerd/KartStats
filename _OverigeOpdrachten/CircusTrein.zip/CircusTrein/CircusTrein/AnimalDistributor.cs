﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircusTrein
{
    public class AnimalDistributor
    {
        public static List<Wagon> DistributeAnimals(List<Animal> animals)
        {
            List<Wagon> wagons = new List<Wagon>();

            // Sort the animals by size, so we can add the larger animals first
            animals = animals.OrderBy(a => a.Size).ToList();

            // Loop over each animal and try to add it to a wagon
            foreach (Animal animal in animals)
            {
                bool addedToExistingWagon = false;

                // Try to add the animal to an existing wagon
                foreach (Wagon wagon in wagons)
                {
                    if (wagon.CanAnimalBeAdded(animal))
                    {
                        wagon.AddAnimal(animal);
                        addedToExistingWagon = true;
                        break;
                    }
                }

                // If the animal couldn't be added to an existing wagon, create a new wagon for it
                if (!addedToExistingWagon)
                {
                    Wagon newWagon = new Wagon();
                    newWagon.AddAnimal(animal);
                    wagons.Add(newWagon);
                }
            }

            // Return the list of wagons
            return wagons;
        }
    }
}
