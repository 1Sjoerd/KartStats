﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircusTrein
{
    public class Wagon
    {
        public List<Animal> Animals { get; private set; }
        public int Points { get; set; }

        public Wagon()
        {
            Animals = new List<Animal>();
        }

        public bool CanAnimalBeAdded(Animal newAnimal)
        {
            // Check if the new animal is compatible with the animals already in the wagon
            foreach (Animal animal in Animals)
            {
                if (newAnimal.FoodType == FoodType.Meat && (newAnimal.Size >= animal.Size || animal.FoodType == FoodType.Meat))
                {
                    return false;
                }
                if (animal.FoodType == FoodType.Meat && (animal.Size >= newAnimal.Size || newAnimal.FoodType == FoodType.Meat))
                {
                    return false;
                }
            }

            // Check if adding the new animal won't exceed the maximum number of points
            int newPoints = Points;
            if (newAnimal.Size == Size.Small)
            {
                newPoints += 1;
            }
            else if (newAnimal.Size == Size.Medium)
            {
                newPoints += 3;
            }
            else if (newAnimal.Size == Size.Large)
            {
                newPoints += 5;
            }

            return newPoints <= 10;
        }

        public void AddAnimal(Animal animal)
        {
            Animals.Add(animal);

            // Update the points
            if (animal.Size == Size.Small)
            {
                Points += 1;
            }
            else if (animal.Size == Size.Medium)
            {
                Points += 3;
            }
            else if (animal.Size == Size.Large)
            {
                Points += 5;
            }
        }

        public void RemoveAnimal(Animal animal)
        {
            this.Animals.Remove(animal);
            this.Points -= (int)animal.Size;
        }
    }

}
