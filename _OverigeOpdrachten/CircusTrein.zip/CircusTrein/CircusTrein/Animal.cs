﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircusTrein
{
    public enum Size
    {
        Small,
        Medium,
        Large
    }

    public enum FoodType
    {
        Meat,
        Plants
    }

    public class Animal
    {
        public string Name { get; set; }
        public Size Size { get; set; }
        public FoodType FoodType { get; set; }
    }
}
