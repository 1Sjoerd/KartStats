﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using static CircusTrein.AnimalDistributor;

namespace CircusTrein
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Animal> animals;

        public MainWindow()
        {
            InitializeComponent();
            sizeComboBox.ItemsSource = Enum.GetValues(typeof(Size)).Cast<Size>();
            foodComboBox.ItemsSource = Enum.GetValues(typeof(FoodType)).Cast<FoodType>();

            animals = new List<Animal>();
            lstbxAnimals.ItemsSource = animals;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            List<Wagon> wagons = DistributeAnimals(this.animals);

            int wagonNumber = 1;
            string text = "";
            foreach (Wagon wagon in wagons)
            {
                text += "Wagon " + wagonNumber + ":" + Environment.NewLine;
                foreach (Animal animal in wagon.Animals)
                {
                    text += animal.Name + " (" + animal.Size + ", " + animal.FoodType + ")" + Environment.NewLine;
                }
                text += "Total points: " + wagon.Points + Environment.NewLine;
                text += Environment.NewLine;
                wagonNumber++;
            }
            txtbxWagons.Text = text;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if(txtbxName.Text.Length == 0 || foodComboBox.SelectedValue == null || sizeComboBox.SelectedValue == null) 
            {
                MessageBox.Show("Not all required fields have been entered.", "Error");
            }
            else
            {
                this.animals.Add(new Animal { Name = txtbxName.Text, Size = (Size)sizeComboBox.SelectedValue, FoodType = (FoodType)foodComboBox.SelectedValue });
                lstbxAnimals.Items.Refresh();
            }
        }

        private void btnRemoveAnimal_Click(object sender, RoutedEventArgs e)
        {
            if ((Animal)lstbxAnimals.SelectedItem == null)
            {
                MessageBox.Show("No animal is selected.", "Error");
            }
            else
            {
                Animal selectedAnimal = (Animal)lstbxAnimals.SelectedItem;
                if (selectedAnimal != null)
                {
                    this.animals.Remove(selectedAnimal);
                    lstbxAnimals.Items.Refresh();
                }
            }
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            this.animals.Clear();
            lstbxAnimals.Items.Refresh();
            txtbxWagons.Text = string.Empty;
            MessageBox.Show("The list of animals has been reset.", "Notification");
        }
    }
}
